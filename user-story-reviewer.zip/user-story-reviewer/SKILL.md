---
name: user-story-reviewer
description: User story quality assessment and improvement tool based on Mike Cohn's "User Stories Applied" methodology. Use when reviewing, evaluating, scoring, or improving user stories. Triggers include requests to "review my user stories", "check my stories", "improve my user stories", "score my stories", "validate my backlog", or any user story quality assessment task.
---

# User Story Reviewer

Review and improve user stories based on Mike Cohn's "User Stories Applied" methodology.

## Review Process

1. **Parse the input** - Extract individual user stories from provided content
2. **Evaluate each story** - Apply INVEST criteria and story smell detection
3. **Calculate scores** - Generate individual and aggregate quality scores
4. **Provide recommendations** - Offer specific, actionable improvements

## INVEST Criteria (Score 0-2 each, max 12 points)

### Independent (0-2)
- **2**: Story can be developed in any order without dependencies
- **1**: Minor dependencies exist but can be managed
- **0**: Story has significant dependencies on other stories

**Fix**: Combine dependent stories or find different split boundaries.

### Negotiable (0-2)
- **2**: Story is a conversation placeholder, not a contract
- **1**: Some unnecessary detail present
- **0**: Too much detail, reads like a specification

**Fix**: Remove implementation details, keep only reminders for conversation.

### Valuable (0-2)
- **2**: Clear value to user or customer; written in business language
- **1**: Value present but obscured by technical language
- **0**: Only valuable to developers or value unclear

**Fix**: Rewrite from user perspective: what problem does this solve?

### Estimatable (0-2)
- **2**: Team can estimate with reasonable confidence
- **1**: Needs some clarification before estimating
- **0**: Cannot estimate (too vague, too large, or unknown domain/technology)

**Fix**: Split into spike + implementation, or gather more domain knowledge.

### Small (0-2)
- **2**: Can be completed in 1-5 days (fits in a single sprint)
- **1**: Borderline size, may need splitting
- **0**: Epic-sized story (weeks of work)

**Fix**: Split using vertical slicing (full cake slices through all layers).

### Testable (0-2)
- **2**: Clear acceptance criteria can be written
- **1**: Tests possible but criteria need clarification
- **0**: Cannot be tested (subjective, vague, or impossible to verify)

**Fix**: Add measurable acceptance criteria; replace "easy" with metrics.

## Story Smell Detection

Deduct 1-2 points for each smell detected:

| Smell | Indicators | Fix |
|-------|------------|-----|
| **UI Too Soon** | Screen names, buttons, fields mentioned in early stories | Remove UI assumptions; describe goal, not interface |
| **Too Many Details** | Story text exceeds 2-3 sentences; reads like requirements doc | Reduce to conversation placeholder |
| **Interdependent** | Stories must be done in specific order | Combine or re-split along different boundaries |
| **Too Small** | Story is less than half a day of work | Combine with related micro-stories |
| **Not Closed** | Story describes ongoing activity with no completion point | Rewrite with achievement-based completion |
| **Missing Role** | No user/actor specified | Add "As a [role]" prefix |
| **Passive Voice** | "A resume can be posted" vs "A user can post a resume" | Rewrite in active voice |
| **Technical Jargon** | Connection pools, APIs, databases in customer-facing stories | Rewrite in business value terms |

## Story Format Evaluation

**Preferred Format** (Connextra template):
```
As a [user role], I want [function/goal] so that [business value/reason]
```

**Acceptable Formats**:
- "[Role] can [action]" - acceptable if value is obvious
- "[Action] for [role]" - requires clear context

**Poor Formats** (needs improvement):
- "The system shall..." - IEEE 830 style, not a story
- Technical descriptions without user context
- Feature lists without user perspective

## Scoring Guide

| Total Score | Rating | Recommendation |
|-------------|--------|----------------|
| 10-12 | Excellent | Ready for sprint planning |
| 7-9 | Good | Minor improvements suggested |
| 4-6 | Needs Work | Requires revision before sprint |
| 0-3 | Poor | Rewrite or split required |

## Output Format

For each story reviewed, provide:

```
### Story: "[Story text]"

**INVEST Score: X/12**
- Independent: X/2 - [brief assessment]
- Negotiable: X/2 - [brief assessment]
- Valuable: X/2 - [brief assessment]
- Estimatable: X/2 - [brief assessment]
- Small: X/2 - [brief assessment]
- Testable: X/2 - [brief assessment]

**Smells Detected**: [list or "None"]

**Rating**: [Excellent/Good/Needs Work/Poor]

**Suggested Improvement**:
[Rewritten story or specific changes]

**Acceptance Test Ideas**:
- [Test case 1]
- [Test case 2]
```

## Aggregate Report

After reviewing all stories, provide:
- **Total stories reviewed**
- **Average INVEST score**
- **Distribution by rating** (Excellent/Good/Needs Work/Poor)
- **Most common issues** (top 3 patterns)
- **Priority improvements** (which stories to fix first)

## Special Cases

### Constraints (Non-functional requirements)
Stories like "System must support 50 concurrent users" are **constraints**, not stories.
- Mark as "Constraint Card"
- Ensure testable criteria exist
- Don't include in INVEST scoring for functional stories

### Epics
Large stories covering weeks of work are **epics** that need splitting.
- Identify as epic
- Suggest splitting approaches (by user workflow, by data type, by CRUD operations)

### Spikes
Investigation tasks should be written as:
- "Research [topic] to determine [decision]"
- Always timebox spikes
- Pair with follow-up implementation story

## Reference

For detailed criteria, examples, and splitting strategies, see [references/invest-criteria.md](references/invest-criteria.md).
