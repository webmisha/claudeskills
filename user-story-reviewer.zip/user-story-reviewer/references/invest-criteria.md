# INVEST Criteria - Detailed Reference

Based on Mike Cohn's "User Stories Applied" methodology.

## Independent

Stories should be self-contained without inherent dependencies.

**Good Example:**
- "As a job seeker, I can search for jobs by keyword"
- "As a job seeker, I can filter jobs by location"

These can be built in any order.

**Bad Example:**
- "As a user, I can log in" (Story A)
- "As a user, I can reset my password" (Story B - depends on A)

**Solutions for Dependencies:**
1. Combine dependent stories into one
2. Re-slice along different boundaries
3. Accept temporary dependency but plan sprints accordingly

## Negotiable

Stories are placeholders for conversation, not contracts.

**Good Example:**
```
As a recruiter, I can post a job listing so that candidates can apply.
```
Details negotiated during sprint planning.

**Bad Example:**
```
As a recruiter, I can post a job by entering a 50-character title, 
500-character description, selecting from 12 predefined categories, 
uploading a company logo (max 200KB, .png or .jpg format)...
```

**Rule:** If it reads like a specification, reduce it.

## Valuable

Every story must deliver value to users or customers.

**Good Example:**
```
As a job seeker, I can save jobs to review later so I don't lose interesting opportunities.
```

**Bad Example:**
```
As a developer, I can refactor the database layer.
```
(Only valuable to team, not customers)

**Fix:** Reframe as: "As a job seeker, I experience faster search results" (if performance is the underlying value).

## Estimatable

Team must be able to estimate the story.

**Three reasons teams can't estimate:**
1. **Lack of domain knowledge** → Talk to product owner
2. **Lack of technical knowledge** → Create a spike
3. **Story is too big** → Split the story

**Spike Example:**
```
Spike: Research payment gateway options (timeboxed: 2 days)
Follow-up: As a buyer, I can pay with credit card
```

## Small

Stories should be 1-5 ideal days of work.

**Splitting Strategies:**

1. **By Workflow Steps**
   - Epic: "User can manage their account"
   - Split: Create account, Update profile, Delete account

2. **By Business Rules**
   - Epic: "Calculate shipping"
   - Split: Domestic shipping, International shipping, Express shipping

3. **By Data Variations**
   - Epic: "Search jobs"
   - Split: By keyword, By location, By salary range

4. **By Interface Variation**
   - Epic: "User can apply for job"
   - Split: Apply via form, Apply with LinkedIn, Apply with resume upload

5. **By CRUD Operations**
   - Create, Read, Update, Delete as separate stories

## Testable

Stories must have clear pass/fail criteria.

**Good Example:**
```
As a job seeker, I can search by salary range.

Acceptance Tests:
- Search for $50k-$75k returns only jobs in that range
- Jobs with "DOE" (depends on experience) excluded from range searches
- Invalid ranges show error message
```

**Bad Example:**
```
As a user, I find the interface easy to use.
```
"Easy" is not testable.

**Fix:** Define measurable criteria:
```
As a new user, I can complete job search in under 30 seconds without help.
```

## Story Smells Quick Reference

| Smell | Example | Fix |
|-------|---------|-----|
| UI Too Soon | "Click the blue Submit button" | "Submit application" |
| Interdependent | "After login, user can..." | Remove "after login" |
| Goldplating | 10 paragraphs of detail | 2-3 sentences max |
| Too Small | "Change button color" | Combine with related UI work |
| Not Closed | "User receives notifications" | "User can enable notifications" |
| Epic in Disguise | "User can manage account" | Split into CRUD operations |

## Acceptance Test Patterns

**Format:**
```
Given [context/precondition]
When [action taken]
Then [expected outcome]
```

**Example:**
```
Story: As a job seeker, I can filter by remote work.

Given I am on the job search page
When I check "Remote only" filter
Then only jobs marked as remote are displayed
And the job count updates to show filtered total
```

## Sizing Reference

| Size | Description | Action |
|------|-------------|--------|
| XS (< 0.5 day) | Too small | Combine with related work |
| S (0.5-1 day) | Ideal minimum | Ready |
| M (2-3 days) | Ideal | Ready |
| L (4-5 days) | Acceptable | Ready, monitor closely |
| XL (> 5 days) | Too large | Split before sprint |
| Epic (weeks) | Way too large | Decompose into multiple stories |
